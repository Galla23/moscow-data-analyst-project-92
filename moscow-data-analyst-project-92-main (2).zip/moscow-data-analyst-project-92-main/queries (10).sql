INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Abraham Bennet','Sunday',232328748),
	 ('Albert Ringer','Sunday',362985486),
	 ('Ann Dull','Sunday',34138287),
	 ('Anne Ringer','Sunday',49050828),
	 ('Burt Gringlesby','Sunday',112782280),
	 ('Charlene Locksley','Sunday',93745116),
	 ('Cheryl Carson','Sunday',69553595),
	 ('Dean Straight','Sunday',176873005),
	 ('Dirk Stringer','Sunday',698820601),
	 ('Heather McBadden','Sunday',266458384);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Innes del Castillo','Sunday',244679491),
	 ('Johnson White','Sunday',88933984),
	 ('Livia Karsen','Sunday',137975384),
	 ('Marjorie Green','Sunday',104815534),
	 ('Meander Smith','Sunday',56678279),
	 ('Michael O''Leary','Sunday',125981634),
	 ('Michel DeFrance','Sunday',438321488),
	 ('Morningstar Greene','Sunday',68473053),
	 ('Reginald Blotchet-Halls','Sunday',80496472),
	 ('Sheryl Hunter','Sunday',148514539);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Stearns MacFeather','Sunday',27431434),
	 ('Sylvia Panteley','Sunday',95337213),
	 ('Abraham Bennet','Monday',231845241),
	 ('Albert Ringer','Monday',392378037),
	 ('Ann Dull','Monday',39656842),
	 ('Anne Ringer','Monday',53386960),
	 ('Burt Gringlesby','Monday',118429815),
	 ('Charlene Locksley','Monday',108450662),
	 ('Cheryl Carson','Monday',77977656),
	 ('Dean Straight','Monday',192550177);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Dirk Stringer','Monday',759341454),
	 ('Heather McBadden','Monday',293014643),
	 ('Innes del Castillo','Monday',260992756),
	 ('Johnson White','Monday',98560781),
	 ('Livia Karsen','Monday',132386625),
	 ('Marjorie Green','Monday',97539868),
	 ('Meander Smith','Monday',52160238),
	 ('Michael O''Leary','Monday',138096277),
	 ('Michel DeFrance','Monday',479584920),
	 ('Morningstar Greene','Monday',67381290);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Reginald Blotchet-Halls','Monday',103178571),
	 ('Sheryl Hunter','Monday',153301531),
	 ('Stearns MacFeather','Monday',30778276),
	 ('Sylvia Panteley','Monday',96399427),
	 ('Abraham Bennet','Tuesday',259058032),
	 ('Albert Ringer','Tuesday',419021705),
	 ('Ann Dull','Tuesday',38097807),
	 ('Anne Ringer','Tuesday',55417862),
	 ('Burt Gringlesby','Tuesday',114454017),
	 ('Charlene Locksley','Tuesday',102419645);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Cheryl Carson','Tuesday',76905547),
	 ('Dean Straight','Tuesday',183459091),
	 ('Dirk Stringer','Tuesday',734550037),
	 ('Heather McBadden','Tuesday',267891418),
	 ('Innes del Castillo','Tuesday',285473369),
	 ('Johnson White','Tuesday',100275590),
	 ('Livia Karsen','Tuesday',145696077),
	 ('Marjorie Green','Tuesday',102488970),
	 ('Meander Smith','Tuesday',63913954),
	 ('Michael O''Leary','Tuesday',125258270);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Michel DeFrance','Tuesday',467420386),
	 ('Morningstar Greene','Tuesday',67737440),
	 ('Reginald Blotchet-Halls','Tuesday',89298153),
	 ('Sheryl Hunter','Tuesday',163754750),
	 ('Stearns MacFeather','Tuesday',31056505),
	 ('Sylvia Panteley','Tuesday',99289901),
	 ('Abraham Bennet','Wednesday',214842815),
	 ('Albert Ringer','Wednesday',403718425),
	 ('Ann Dull','Wednesday',35589006),
	 ('Anne Ringer','Wednesday',46106241);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Burt Gringlesby','Wednesday',119047498),
	 ('Charlene Locksley','Wednesday',106731411),
	 ('Cheryl Carson','Wednesday',66729906),
	 ('Dean Straight','Wednesday',168092851),
	 ('Dirk Stringer','Wednesday',642376642),
	 ('Heather McBadden','Wednesday',249479672),
	 ('Innes del Castillo','Wednesday',245730067),
	 ('Johnson White','Wednesday',89036568),
	 ('Livia Karsen','Wednesday',156662691),
	 ('Marjorie Green','Wednesday',94949352);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Meander Smith','Wednesday',49655899),
	 ('Michael O''Leary','Wednesday',134525040),
	 ('Michel DeFrance','Wednesday',439203900),
	 ('Morningstar Greene','Wednesday',64838804),
	 ('Reginald Blotchet-Halls','Wednesday',80548671),
	 ('Sheryl Hunter','Wednesday',140290965),
	 ('Stearns MacFeather','Wednesday',24953854),
	 ('Sylvia Panteley','Wednesday',85876350),
	 ('Abraham Bennet','Thursday',226133920),
	 ('Albert Ringer','Thursday',405676715);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Ann Dull','Thursday',36627441),
	 ('Anne Ringer','Thursday',55678731),
	 ('Burt Gringlesby','Thursday',103250742),
	 ('Charlene Locksley','Thursday',102081557),
	 ('Cheryl Carson','Thursday',70730736),
	 ('Dean Straight','Thursday',182913507),
	 ('Dirk Stringer','Thursday',693463720),
	 ('Heather McBadden','Thursday',289587875),
	 ('Innes del Castillo','Thursday',247744631),
	 ('Johnson White','Thursday',91715664);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Livia Karsen','Thursday',168820566),
	 ('Marjorie Green','Thursday',90204716),
	 ('Meander Smith','Thursday',56688841),
	 ('Michael O''Leary','Thursday',130193802),
	 ('Michel DeFrance','Thursday',481154816),
	 ('Morningstar Greene','Thursday',61407061),
	 ('Reginald Blotchet-Halls','Thursday',89971577),
	 ('Sheryl Hunter','Thursday',148434253),
	 ('Stearns MacFeather','Thursday',22585496),
	 ('Sylvia Panteley','Thursday',91590683);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Abraham Bennet','Friday',233935361),
	 ('Albert Ringer','Friday',357492148),
	 ('Ann Dull','Friday',37433122),
	 ('Anne Ringer','Friday',51753352),
	 ('Burt Gringlesby','Friday',109360163),
	 ('Charlene Locksley','Friday',97761374),
	 ('Cheryl Carson','Friday',80473505),
	 ('Dean Straight','Friday',176048824),
	 ('Dirk Stringer','Friday',672023523),
	 ('Heather McBadden','Friday',245868793);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Innes del Castillo','Friday',231816497),
	 ('Johnson White','Friday',91757929),
	 ('Livia Karsen','Friday',172939429),
	 ('Marjorie Green','Friday',99954936),
	 ('Meander Smith','Friday',53551957),
	 ('Michael O''Leary','Friday',142326764),
	 ('Michel DeFrance','Friday',473980678),
	 ('Morningstar Greene','Friday',62929144),
	 ('Reginald Blotchet-Halls','Friday',96796981),
	 ('Sheryl Hunter','Friday',158669557);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Stearns MacFeather','Friday',28022436),
	 ('Sylvia Panteley','Friday',91390800),
	 ('Abraham Bennet','Saturday',219357051),
	 ('Albert Ringer','Saturday',359055422),
	 ('Ann Dull','Saturday',37658782),
	 ('Anne Ringer','Saturday',48579237),
	 ('Burt Gringlesby','Saturday',108212068),
	 ('Charlene Locksley','Saturday',100507641),
	 ('Cheryl Carson','Saturday',69224918),
	 ('Dean Straight','Saturday',176094743);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Dirk Stringer','Saturday',724561952),
	 ('Heather McBadden','Saturday',260891531),
	 ('Innes del Castillo','Saturday',245765313),
	 ('Johnson White','Saturday',91955960),
	 ('Livia Karsen','Saturday',142421334),
	 ('Marjorie Green','Saturday',95303142),
	 ('Meander Smith','Saturday',53094397),
	 ('Michael O''Leary','Saturday',131118669),
	 ('Michel DeFrance','Saturday',480574641),
	 ('Morningstar Greene','Saturday',64598714);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  TRIM(TO_CHAR(s.sale_date, 'Day')) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM sales s
JOIN employees e ON s.sales_person_id = e.employee_id
JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  s.sales_person_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Reginald Blotchet-Halls','Saturday',92451664),
	 ('Sheryl Hunter','Saturday',143802265),
	 ('Stearns MacFeather','Saturday',27623848),
	 ('Sylvia Panteley','Saturday',87097890);
