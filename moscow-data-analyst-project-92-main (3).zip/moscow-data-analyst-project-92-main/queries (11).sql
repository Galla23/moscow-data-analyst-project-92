INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Abraham Bennet','sunday',232328748),
	 ('Albert Ringer','sunday',362985486),
	 ('Ann Dull','sunday',34138287),
	 ('Anne Ringer','sunday',49050828),
	 ('Burt Gringlesby','sunday',112782280),
	 ('Charlene Locksley','sunday',93745116),
	 ('Cheryl Carson','sunday',69553595),
	 ('Dean Straight','sunday',176873005),
	 ('Dirk Stringer','sunday',698820601),
	 ('Heather McBadden','sunday',266458384);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Innes del Castillo','sunday',244679491),
	 ('Johnson White','sunday',88933984),
	 ('Livia Karsen','sunday',137975384),
	 ('Marjorie Green','sunday',104815534),
	 ('Meander Smith','sunday',56678279),
	 ('Michael O''Leary','sunday',125981634),
	 ('Michel DeFrance','sunday',438321488),
	 ('Morningstar Greene','sunday',68473053),
	 ('Reginald Blotchet-Halls','sunday',80496472),
	 ('Sheryl Hunter','sunday',148514539);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Stearns MacFeather','sunday',27431434),
	 ('Sylvia Panteley','sunday',95337213),
	 ('Abraham Bennet','monday',231845241),
	 ('Albert Ringer','monday',392378037),
	 ('Ann Dull','monday',39656842),
	 ('Anne Ringer','monday',53386960),
	 ('Burt Gringlesby','monday',118429815),
	 ('Charlene Locksley','monday',108450662),
	 ('Cheryl Carson','monday',77977656),
	 ('Dean Straight','monday',192550177);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Dirk Stringer','monday',759341454),
	 ('Heather McBadden','monday',293014643),
	 ('Innes del Castillo','monday',260992756),
	 ('Johnson White','monday',98560781),
	 ('Livia Karsen','monday',132386625),
	 ('Marjorie Green','monday',97539868),
	 ('Meander Smith','monday',52160238),
	 ('Michael O''Leary','monday',138096277),
	 ('Michel DeFrance','monday',479584920),
	 ('Morningstar Greene','monday',67381290);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Reginald Blotchet-Halls','monday',103178571),
	 ('Sheryl Hunter','monday',153301531),
	 ('Stearns MacFeather','monday',30778276),
	 ('Sylvia Panteley','monday',96399427),
	 ('Abraham Bennet','tuesday',259058032),
	 ('Albert Ringer','tuesday',419021705),
	 ('Ann Dull','tuesday',38097807),
	 ('Anne Ringer','tuesday',55417862),
	 ('Burt Gringlesby','tuesday',114454017),
	 ('Charlene Locksley','tuesday',102419645);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Cheryl Carson','tuesday',76905547),
	 ('Dean Straight','tuesday',183459091),
	 ('Dirk Stringer','tuesday',734550037),
	 ('Heather McBadden','tuesday',267891418),
	 ('Innes del Castillo','tuesday',285473369),
	 ('Johnson White','tuesday',100275590),
	 ('Livia Karsen','tuesday',145696077),
	 ('Marjorie Green','tuesday',102488970),
	 ('Meander Smith','tuesday',63913954),
	 ('Michael O''Leary','tuesday',125258270);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Michel DeFrance','tuesday',467420386),
	 ('Morningstar Greene','tuesday',67737440),
	 ('Reginald Blotchet-Halls','tuesday',89298153),
	 ('Sheryl Hunter','tuesday',163754750),
	 ('Stearns MacFeather','tuesday',31056505),
	 ('Sylvia Panteley','tuesday',99289901),
	 ('Abraham Bennet','wednesday',214842815),
	 ('Albert Ringer','wednesday',403718425),
	 ('Ann Dull','wednesday',35589006),
	 ('Anne Ringer','wednesday',46106241);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Burt Gringlesby','wednesday',119047498),
	 ('Charlene Locksley','wednesday',106731411),
	 ('Cheryl Carson','wednesday',66729906),
	 ('Dean Straight','wednesday',168092851),
	 ('Dirk Stringer','wednesday',642376642),
	 ('Heather McBadden','wednesday',249479672),
	 ('Innes del Castillo','wednesday',245730067),
	 ('Johnson White','wednesday',89036568),
	 ('Livia Karsen','wednesday',156662691),
	 ('Marjorie Green','wednesday',94949352);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Meander Smith','wednesday',49655899),
	 ('Michael O''Leary','wednesday',134525040),
	 ('Michel DeFrance','wednesday',439203900),
	 ('Morningstar Greene','wednesday',64838804),
	 ('Reginald Blotchet-Halls','wednesday',80548671),
	 ('Sheryl Hunter','wednesday',140290965),
	 ('Stearns MacFeather','wednesday',24953854),
	 ('Sylvia Panteley','wednesday',85876350),
	 ('Abraham Bennet','thursday',226133920),
	 ('Albert Ringer','thursday',405676715);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Ann Dull','thursday',36627441),
	 ('Anne Ringer','thursday',55678731),
	 ('Burt Gringlesby','thursday',103250742),
	 ('Charlene Locksley','thursday',102081557),
	 ('Cheryl Carson','thursday',70730736),
	 ('Dean Straight','thursday',182913507),
	 ('Dirk Stringer','thursday',693463720),
	 ('Heather McBadden','thursday',289587875),
	 ('Innes del Castillo','thursday',247744631),
	 ('Johnson White','thursday',91715664);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Livia Karsen','thursday',168820566),
	 ('Marjorie Green','thursday',90204716),
	 ('Meander Smith','thursday',56688841),
	 ('Michael O''Leary','thursday',130193802),
	 ('Michel DeFrance','thursday',481154816),
	 ('Morningstar Greene','thursday',61407061),
	 ('Reginald Blotchet-Halls','thursday',89971577),
	 ('Sheryl Hunter','thursday',148434253),
	 ('Stearns MacFeather','thursday',22585496),
	 ('Sylvia Panteley','thursday',91590683);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Abraham Bennet','friday',233935361),
	 ('Albert Ringer','friday',357492148),
	 ('Ann Dull','friday',37433122),
	 ('Anne Ringer','friday',51753352),
	 ('Burt Gringlesby','friday',109360163),
	 ('Charlene Locksley','friday',97761374),
	 ('Cheryl Carson','friday',80473505),
	 ('Dean Straight','friday',176048824),
	 ('Dirk Stringer','friday',672023523),
	 ('Heather McBadden','friday',245868793);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Innes del Castillo','friday',231816497),
	 ('Johnson White','friday',91757929),
	 ('Livia Karsen','friday',172939429),
	 ('Marjorie Green','friday',99954936),
	 ('Meander Smith','friday',53551957),
	 ('Michael O''Leary','friday',142326764),
	 ('Michel DeFrance','friday',473980678),
	 ('Morningstar Greene','friday',62929144),
	 ('Reginald Blotchet-Halls','friday',96796981),
	 ('Sheryl Hunter','friday',158669557);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Stearns MacFeather','friday',28022436),
	 ('Sylvia Panteley','friday',91390800),
	 ('Abraham Bennet','saturday',219357051),
	 ('Albert Ringer','saturday',359055422),
	 ('Ann Dull','saturday',37658782),
	 ('Anne Ringer','saturday',48579237),
	 ('Burt Gringlesby','saturday',108212068),
	 ('Charlene Locksley','saturday',100507641),
	 ('Cheryl Carson','saturday',69224918),
	 ('Dean Straight','saturday',176094743);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Dirk Stringer','saturday',724561952),
	 ('Heather McBadden','saturday',260891531),
	 ('Innes del Castillo','saturday',245765313),
	 ('Johnson White','saturday',91955960),
	 ('Livia Karsen','saturday',142421334),
	 ('Marjorie Green','saturday',95303142),
	 ('Meander Smith','saturday',53094397),
	 ('Michael O''Leary','saturday',131118669),
	 ('Michel DeFrance','saturday',480574641),
	 ('Morningstar Greene','saturday',64598714);
INSERT INTO "SELECT
  CONCAT(e.first_name, ' ', e.last_name) AS seller,
  LOWER(TRIM(TO_CHAR(s.sale_date, 'Day'))) AS day_of_week,
  FLOOR(SUM(p.price * s.quantity)) AS income
FROM
  sales s
  JOIN employees e ON s.sales_person_id = e.employee_id
  JOIN products p ON s.product_id = p.product_id
GROUP BY
  e.first_name,
  e.last_name,
  e.employee_id,
  TO_CHAR(s.sale_date, 'Day'),
  EXTRACT(DOW FROM s.sale_date)
ORDER BY
  EXTRACT(DOW FROM s.sale_date),
  seller" (seller,day_of_week,income) VALUES
	 ('Reginald Blotchet-Halls','saturday',92451664),
	 ('Sheryl Hunter','saturday',143802265),
	 ('Stearns MacFeather','saturday',27623848),
	 ('Sylvia Panteley','saturday',87097890);
